#AWS-dynamic-DNS

Dynamic DNS via AWS for those without static IPs.

Created with Serverless v1.4
